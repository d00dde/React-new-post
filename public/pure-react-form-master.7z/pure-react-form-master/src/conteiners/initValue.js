export const initValues = {
    firstName: '',
    lastName: '',
    age: '',
    email: '',
    password: '',
    confirmPassword: ''
};

export const validateFields = {
    firstName: '',
    email: '',
    password: '',
    confirmPassword: ''
}
