import React, { Component } from 'react';

const Header = () => {
    return (
        <div>
            <h1>React Form Without Redux</h1>
        </div>
    )
}

export default Header;
