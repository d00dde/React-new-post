# Pure-React-Form
Pure React Form without state managment like redux, mobX or others.

Here I want to show, how can Youse basic react tools to create auth form with validation, notification and preloader.

Here I use [HoC](https://reactjs.org/docs/higher-order-components.html)

to start clone this repos or download

    npm i - install packeges
    npm run dev - run development mode
    npm run build - run production mode
